<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\Customer;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Place>
 */
class PlaceFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            //
            'customer_phone'=>$this->faker->randomElement(Customer::all())['phone'],
            'description'=>$this->faker->address(),
            'longitude'=>random_int(0,100),
            'latitude'=>random_int(0,100)
        ];
    }
}
