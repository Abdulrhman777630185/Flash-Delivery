<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Driver>
 */
class DriverFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'name'=>$this->faker->name(),
            'phone'=>random_int(777000111,781000000),
            'password'=>random_int(1000,9999),
            'image'=>'images/q.jpg',
            'blance'=>random_int(50000,80000),
            'evaluation'=>random_int(0,5),
            'current_location'=>$this->faker->address(),
            'blocked'=>random_int(0,1),
            'means_of_transport'=>$this->faker->randomElement(['Motorcycle','Taxi']),
            'driver_Degree'=>$this->faker->randomElement(["First-Degree-Driver","Second-Degree-Driver"]),
        ];
    }
}
