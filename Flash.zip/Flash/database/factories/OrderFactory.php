<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\Customer;
/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Order>
 */
class OrderFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            //'customerPhone'=>randomElement(Customers::class),
            'customer_phone'=>$this->faker->randomElement(Customer::all())['phone'],
            'from_location'=>$this->faker->address(),
            'to_location'=>$this->faker->address(),
            'delivery_time'=>$this->faker->time('H:i:s'),
            'order_type'=>$this->faker->text(5),
            'means_of_transport'=>$this->faker->randomElement(['Motorcycle','Taxi']),
            'payment_method'=>$this->faker->randomElement(['UponDelivery','UponRecipt']),
            'recipient_name'=>$this->faker->name(),
            'recipient_phone'=>random_int(000000,999999),
            'delivery_amount'=>random_int(1000,9999),
            'order_status'=>$this->faker->randomElement(["ExecutableFirstOrder","Executable","OrderOnWay","Accomplish","CanceledByUser","CanceledByDriver","CanceledByAdmin"]),
        ];
    }
}
