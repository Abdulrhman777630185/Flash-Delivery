<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\Driver;
use App\Models\Order;
use App\Models\Customer;
/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Deliveries>
 */
class DeliveriesFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'order_id'=>$this->faker->randomElement(Order::all())['id'],
            'driver_id'=>$this->faker->randomElement(Driver::all())['id'],
            'customer_phone'=>$this->faker->randomElement(Customer::all())['phone'],
            'evaluation'=>$this->faker->randomElement(['5','4','3','2','1']),
            'deliverie_status'=>$this->faker->randomElement(Order::all())['order_status'],
           ];
    }
}
