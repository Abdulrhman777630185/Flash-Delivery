<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\Driver;

use App\Models\Order;
/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Urgent_Order>
 */
class UrgentOrderFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'order_id'=>$this->faker->randomElement(Order::all())['id'],
            'current_location_driver'=>$this->faker->randomElement(Driver::all())['current_location'],
            'status'=>$this->faker->randomElement(["Executable","OrderOnWay","Accomplish"]),
            'means_of_transport'=>$this->faker->randomElement(Order::all())['means_of_transport'],
            'phone_driver'=>random_int(777000000,999999999),
            'from_location'=>$this->faker->address(),
            'to_location'=>$this->faker->address(),
            'recipient_name'=>$this->faker->name(), 
            'recipient_phone'=>random_int(777000000,999999999),
            'delivery_amount'=>random_int(1000,9999),
            'phone_rescuer_driver'=>random_int(777000000,999999999), 
            
        ];
    }
}
