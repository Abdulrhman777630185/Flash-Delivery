<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Customer;
use App\Models\Driver;
use App\Models\Admin;
use App\Models\Order;
use App\Models\UrgentOrder;
use App\Models\Deliveries;
use App\Models\Place;
class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        Admin::factory(10)->create();
        Customer::factory(10)->create();
        Driver::factory(10)->create();
        Order::factory(20)->create();
        UrgentOrder::factory(20)->create();
        Deliveries::factory(20)->create();
        Place::factory(5)->create();
    }
}
