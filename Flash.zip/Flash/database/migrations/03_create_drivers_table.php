<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('drivers', function (Blueprint $table) {
            $table->engine ='InnoDB';
            $table->increments('id')->comment("رقم السائق");
            $table->string('name',64)->unique()->comment("اسم السائق");
            $table->integer('phone')->comment("رقم جوال السائق");
            $table->string('password',64)->comment("كلمة السر");
            $table->string('image')->nullable()->comment("صورة السائق");
            $table->integer('blance')->unsigned() ->comment("رصيد السائق");
            $table->integer('evaluation')->nullable()->comment("تقييم السائق");
            $table->string('current_location')->nullable()->comment("موقع السائق");
            $table->boolean('blocked')->default(1)->comment("حالة السائق محظور او لا");
            $table->enum('means_of_transport',array("Motorcycle","Taxi"))->comment("نوع المركبة");
            $table->enum('driver_Degree',array("First-Degree-Driver","Second-Degree-Driver"))->comment("درجة السائق");
            $table->timestamps();
           
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('drivers');
    }
};
