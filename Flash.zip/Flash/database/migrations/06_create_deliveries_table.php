<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('deliveries', function (Blueprint $table) {
            $table->engine ='InnoDB';
            $table->increments('id')->comment("رقم عملية التوصيل");
            $table->unsignedInteger('order_id')->comment("رقم الطلب الاساسي");
            $table->unsignedInteger('driver_id')->comment("رقم السائق");
            $table->integer('customer_phone')->comment("رقم جوال العميل");
            $table->integer('evaluation')->nullable()->comment("تقييم عملية التوصيل");
            $table->enum('deliverie_status',array("ExecutableFirstOrder","Executable","OrderOnWay","OrderOnWayEmergency","Accomplish","CanceledByUser","CanceledByDriver","CanceledByAdmin"))->comment("حالة الطلب الحالية");
            $table->foreign('customer_phone')->references('phone')->on('customers')->onDelete('cascade');
            $table->foreign('driver_id')->references("id")->on('drivers')->onDelete('cascade');
            $table->foreign('order_id')->references("id")->on('orders')->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('deliveries');
    }
};
