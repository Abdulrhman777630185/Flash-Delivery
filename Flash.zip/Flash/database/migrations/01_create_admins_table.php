<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('admins', function (Blueprint $table) {
            $table->engine ='InnoDB';
            $table->increments('id')->comment("رقم المدير");
            $table->string('name',64)->unique()->comment("اسم المدير");
            $table->integer('phone')->comment("رقم جوال المدير");
            $table->string('password',64)->comment("كلمة السر للمدير");
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('admins');
    }
};
