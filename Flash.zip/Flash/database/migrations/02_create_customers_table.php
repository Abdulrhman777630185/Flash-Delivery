<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('customers', function (Blueprint $table) {
            $table->engine ='InnoDB';
            $table->increments('id')->comment("رقم العميل");
            $table->string('name',64)->unique()->comment("اسم العميل");
            $table->integer('phone')->unique()->comment("رقم جوال العميل");
            $table->string('password',64)->comment("كلمة السر للعميل");
            $table->string('image')->nullable()->comment("صورة العميل");
            $table->boolean('blocked')->default(1)->comment("حالة العميل محظور او لا");
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('customers');
    }
};
