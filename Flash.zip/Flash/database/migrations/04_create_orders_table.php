<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->engine ='InnoDB';
            $table->increments('id')->comment("رقم الطلب");
            $table->integer('customer_phone')->comment("رقم جوال العميل");
            $table->string('from_location')->comment("موقع الاستلام");
            $table->string('to_location')->comment("موقع التسليم");
            $table->time('delivery_time')->comment("زمن التوصيل");
            $table->string('order_type',64)->comment("نوع الطلب");
            $table->enum('means_of_transport',array("Motorcycle","Taxi"))->comment("نوع وسيلة التوصيل");
            $table->enum('payment_method',array("UponDelivery","UponRecipt"))->comment("وسيلة الدفع");
            $table->string('recipient_name')->comment("اسم المستلم");
            $table->integer('recipient_phone')->comment("رقم جوال المستلم");
            $table->integer('delivery_amount')->unsigned()->comment("مبلغ التوصيل");
            $table->enum('order_status',array("ExecutableFirstOrder","Executable","OrderOnWay","OrderOnWayEmergency","Accomplish","CanceledByUser","CanceledByDriver","CanceledByAdmin"))->comment("حالة الطلب الحالية");
            $table->foreign('customer_phone')->references('phone')->on('customers')->onDelete('cascade');
            $table->timestamps();  
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('orders');
    }
};
