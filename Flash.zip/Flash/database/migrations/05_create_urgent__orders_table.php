<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('urgent_orders', function (Blueprint $table) {
            $table->engine ='InnoDB';
            $table->increments('id')->comment("رقم الطلب الحرج");
            $table->unsignedInteger('order_id')->comment("رقم الطلب الاساسي");
            $table->string('current_location_driver')->comment("موقع السائق - طالب الاستغاثه");
            $table->integer('phone_driver')->comment("موقع السائق - طالب الاستغاثه");
            $table->string('from_location')->comment("موقع الاستلام");
            $table->string('to_location')->comment("موقع التسليم");
            $table->string('recipient_name')->comment("اسم المستلم");
            $table->integer('recipient_phone')->comment("رقم جوال المستلم");
            $table->integer('delivery_amount')->unsigned()->comment("مبلغ التوصيل");
            $table->integer('phone_rescuer_driver')->nullable()->comment("رقم السائق - المنقذ");
            $table->enum('means_of_transport',array("Motorcycle","Taxi"))->comment("نوع وسيلة التوصيل");
            $table->enum('status',array("Executable","OrderOnWay","Accomplish"))->comment("حالة الطلب الحالية");
            $table->foreign('order_id')->references("id")->on('orders')->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('urgent__orders');
    }
};
