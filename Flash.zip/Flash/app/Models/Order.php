<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory;
    protected $fillable=[
        'customer_phone',
        'from_location',
        'to_location',

        'delivery_time',
        'order_type',
        'means_of_transport',

        'payment_method',
        'recipient_name',
        'recipient_phone',

        'delivery_amount',
        'order_status',
        'created_at',   
];

protected $hidden = [
    'updated_at'
];
}
