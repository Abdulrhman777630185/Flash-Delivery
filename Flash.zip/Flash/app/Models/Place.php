<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Place extends Model
{
    use HasFactory;

    protected $fillable=[
        'customer_phone',
        'description',   
        'longitude',
        'latitude'
];

protected $hidden = [
    'created_at',
    'updated_at'
];
}
