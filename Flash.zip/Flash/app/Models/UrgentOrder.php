<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UrgentOrder extends Model
{
    use HasFactory;
    
    protected $fillable=[
        'order_id',
        'screechy_id',
        'current_location_driver',
        'phone_driver',
        'from_location',
        'to_location',
        'recipient_name',
        'recipient_phone',
        'means_of_transport',
        'delivery_amount',
        'phone_rescuer_driver',
        'status'
];

protected $hidden = [
    'created_at',
    'updated_at'
];
}
