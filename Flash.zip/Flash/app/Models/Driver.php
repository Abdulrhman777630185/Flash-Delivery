<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Driver extends Model
{
    use HasFactory;
    protected $fillable=[
        'name',
        'phone',
        'password',
        'image',
        'blance',
        'evaluation',
        'current_location',
        'means_of_transport',
        'driver_Degree',
        'blocked'
];

protected $hidden = [
    'created_at',
    'updated_at'
];
}
