<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    use HasFactory;

     //it's function allows write and edite columns in database
     protected $fillable = [
        'name',
        'phone',
        'password',
        'image',
        'blocked'
    ];

    //it's function write the date and time of entry data to database
    protected $hidden = [
        'created_at',
        'updated_at'
    ];
}
