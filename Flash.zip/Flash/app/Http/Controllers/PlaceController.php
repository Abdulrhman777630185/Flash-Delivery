<?php

namespace App\Http\Controllers;
use App\Models\Place;


use Illuminate\Http\Request;

class PlaceController extends Controller
{
    public function getAllPlaces()
   {
    $Place=Place::all();
    return response()->json($Place);
   }
   
   public function storePlace(Request $request)
   {
    $Place = new Place;
    $Place->customer_phone = $request-> customer_phone;
    $Place->description = $request-> description;
    $Place->longitude = $request-> longitude;
    $Place->latitude = $request-> latitude;
    $Place->save();
    if($Place){
        return response()->json("Insert Place Success!");
    }else{
        return response()->json("Insert Place fail!");
    }
   }


   public function getLatLng($description)
   {
    $Place =  Place::where('description',$description)->get();
    if($Place){
        return response()->json($Place);
    }else{
        return response()->json("Not  found description");
    }
   }

   
}
