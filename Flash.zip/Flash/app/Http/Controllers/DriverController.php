<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Driver;

class DriverController extends Controller
{
    
    public function getAllDrivers()
    {
     $Driver=Driver::all();
     return response()->json($Driver);
    }

      //it's function create customer only
   public function register(Request $request)
   {
    $Driver = new Driver;
    $Driver->name = $request-> name;
    $Driver->phone = $request-> phone;
    $Driver->password = $request-> password;
    $Driver->means_of_transport = $request-> means_of_transport;
    $Driver->driver_Degree = $request-> driver_Degree;
    $Driver->blance = $request-> blance;
    $Driver->save();
    if($Driver){
        return response()->json("register Success!");
    }else{
        return response()->json("register fail!");
    }
   }

   public function setLocation(Request $request,$id)
   {
    $Driver =  Driver::find($id);
    $Driver->current_location = $request-> current_location;
    $Driver->save();
    if($Driver){
        return response()->json("setLocation Success!");
    }else{
        return response()->json("setLocation fail!");
    }
   }

    public function update(Request $request,$id)
   {
    $Driver =  Driver::find($id);
    $Driver->name = $request-> name;
    $Driver->phone = $request-> phone;
    $Driver->password = $request-> password;
    $Driver->image = $request-> image;
    $Driver->blance = $request-> blance;
    $Driver->evaluation = $request-> evaluation;
    $Driver->current_location = $request-> current_location;
    $Driver->means_of_transport = $request-> means_of_transport;
    $Driver->driver_Degree = $request-> driver_Degree;
    $Driver->save();
    if($Driver){
        return response()->json("update Success!");
    }else{
        return response()->json("update fail!");
    }
   }

 

    public function login(Request $request)
   {
    $Driver = new Driver;
    $Driver->name = $request-> name;
    $Driver->password = $request-> password;
    $DriverBlocked =  Driver::where('name',$request-> name)->first();
    $temp_name = Driver::whereIn('Name',[$Driver->name])->get('Name');
    $temp_password = Driver::whereIn('Password',[$Driver->password])->get('Password');
    if($temp_name->contains("Name",$Driver->name) && $temp_password->contains("Password",$Driver->password)){
        $temp_blocked = $DriverBlocked->blocked;
        if(!$temp_blocked == 1){
            return response()->json("driver is blocked");
        }else{
            return response()->json("Login Success!");
        }
    }
    return response()->json("Error in laravel");
   }
   

   
   public function loginFirstDegreeDriver(Request $request)
   {
    $Driver = new Driver;
    $Driver->name = $request-> name;
    $Driver->password = $request-> password;
    $DriverBlocked =  Driver::where('name',$request-> name)->first();
    $temp_name = Driver::whereIn('Name',[$Driver->name])->get('Name');
    $temp_password = Driver::whereIn('Password',[$Driver->password])->get('Password');

    if($temp_name->contains("Name",$Driver->name) && $temp_password->contains("Password",$Driver->password)){
        $temp_blocked = $DriverBlocked->blocked;
        $temp_driver_Degree = $DriverBlocked->driver_Degree;
        if(!$temp_blocked == 1){
            return response()->json("driver is blocked");
        }else{
            if($temp_driver_Degree == "Second-Degree-Driver"){
                return response()->json("cannot login reason second-class-driver");
            }else{
                //return response()->json($temp_driver_Degree);
                return response()->json("Login Success!");
            }       
        }
    }
    return response()->json("Error in laravel");
   }

   public function getDetailsDriverByName(Request $request)
   {
    $Driver = new Driver;
    $Driver->name = $request-> name;
    $Driver =  Driver::where('name',$request-> name)->first();
    
    $Driver_ID = $Driver->id;

    $DriverNew =  Driver::where('id',$Driver_ID)->first();
    
    if($DriverNew){
        return response()->json($DriverNew);
     }else{
         return response()->json("No Found User!");
     }

   }


   
    public function delete($Id)
    {
     $Driver=Driver::find($Id);
     $Driver->delete();
     if($Driver){
        return response()->json("delete Success!");
     }else{
         return response()->json("delete fail!");
     }
    }
    
    public function updateDriverBlocked(Request $request,$id)
    {
     $Driver =  Driver::find($id);
     $Driver->blocked = $request-> blocked;
     $Driver->save();
     if($Driver){
         return response()->json("updateDriverBlocked Success!");
     }else{
         return response()->json("updateDriverBlocked fail!");
     }
    }

    public function getDetailsDriverByID($id)
    {
    $Driver =  Driver::where('id',$id)->first();
     if($Driver){
         return response()->json($Driver);
     }else{
         return response()->json("Not Found Details Driver!");
     }
    }



}
