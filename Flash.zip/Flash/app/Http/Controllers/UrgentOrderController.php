<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UrgentOrder;
use App\Models\Order;
use App\Models\Driver;
use App\Models\Deliveries;


class UrgentOrderController extends Controller
{
    //
    public function getAllUrgentOrders()
    {
     $UrgentOrder=UrgentOrder::all();
     return response()->json($UrgentOrder);
    }

    public function store(Request $request)
   {
    $UrgentOrder = new UrgentOrder;
    $UrgentOrder->order_id = $request-> order_id;
    $UrgentOrder->current_location_driver = $request-> current_location_driver;
    $UrgentOrder->phone_driver = $request-> phone_driver;
    $UrgentOrder->from_location = $request->from_location;
    $UrgentOrder->to_location = $request-> to_location;
    $UrgentOrder->recipient_name = $request-> recipient_name;
    $UrgentOrder->recipient_phone = $request->recipient_phone;
    $UrgentOrder->means_of_transport = $request-> means_of_transport;
    $UrgentOrder->delivery_amount = $request-> delivery_amount;
    $UrgentOrder->phone_rescuer_driver = $request-> phone_rescuer_driver;
    $UrgentOrder->status = $request-> status;
    $UrgentOrder->save();

    $order =  Order::where('id',$request->order_id)->first();
    $order->order_status = "OrderOnWayEmergency";
    $order->save();

    $Deliveries =  Deliveries::where('order_id',$request->order_id)->first();
    $Deliveries->deliverie_status = "OrderOnWayEmergency";
    $Deliveries->save();


    if($UrgentOrder){
        return response()->json("Insert Success!");
    }else{
        return response()->json("Insert fail!");
    }
   }

   public function delete($Id)
   {
    $UrgentOrder=UrgentOrder::find($Id);
    $UrgentOrder->delete();
    if($UrgentOrder){
       return response()->json("delete Success!");
    }else{
        return response()->json("delete fail!");
    }
   }

   public function oneUrgentOrder($id)
   {
    $UrgentOrder =  UrgentOrder::where('id',$id)->get();
    if($UrgentOrder){
        return response()->json($UrgentOrder);
    }else{
        return response()->json("There are no orders identical to the mobile number!");
    }
   }


   //this function not work  
   public function updateUrgentOrderStatus(Request $request,$id)
   {
    $UrgentOrder =  UrgentOrder::find($id);
    $UrgentOrder->status = $request-> status;
    $UrgentOrder->save();
    
    $Order =  Order::find($UrgentOrder->order_id);
    $Order->order_status = $request-> status;
    $Order->save();

    $Deliveries =  Deliveries::where('order_id',$UrgentOrder->order_id)->first();
    $Deliveries->deliverie_status = $request-> status;
    $Deliveries->save();
    


    if($UrgentOrder){
        return response()->json("updateUrgentOrderStatus Success!");
    }else{
        return response()->json("updateUrgentOrderStatus fail!");
    }
   }

//this function not work   
   public function updateUrgentOrderStatusAndRescuer(Request $request,$id)
   {
    $UrgentOrder =  UrgentOrder::find($id);
    $UrgentOrder->status = $request->status;

    $UrgentOrder->phone_rescuer_driver = $request->phone_rescuer_driver;
    $UrgentOrder->save();
    
    if($UrgentOrder){
        return response()->json("updateUrgentOrderStatusAndRescuer Success!");
    }else{
        return response()->json("updateUrgentOrderStatusAndRescuer fail!");
    }
   }
    
}
