<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Admin;

class AdminController extends Controller
{
    //
    //it's function get all Customers
   public function getAllAdmin()
   {
    $Admin=Admin::all();
    return response()->json($Admin);
   }


   public function delete($id)
   {
    $Admin=Admin::find($id);
    $Admin->delete();
    if($Admin){
        return response()->json("delete Success!!!");
    }else{
        return response()->json("delete fail!");
    }
   }


   public function register(Request $request)
   {
    $Admin = new Admin;
    $Admin->name = $request-> name;
    $Admin->phone = $request-> phone;
    $Admin->password = $request-> password;
    $Admin->save();
    if($Admin){
        return response()->json("register Success!");
    }else{
        return response()->json("register fail!");
    }
   }


    //it's function check name and password from table customers
    public function login(Request $request)
    {
     $Admin = new Admin;
     $Admin->name = $request-> name;
     $Admin->password = $request-> password;
     $temp_name = Admin::whereIn('Name',[$Admin->name])->get('Name');
     $temp_password = Admin::whereIn('Password',[$Admin->password])->get('Password');
     if($temp_name->contains("Name",$Admin->name) && $temp_password->contains("Password",$Admin->password)){
         return response()->json("Login Success!");
     }else{
         return response()->json("Login fail!");
     }
     return response()->json("Error in laravel");
    }


    public function update(Request $request,$id)
    {
     $Admin =  Admin::find($id);
     $Admin->name = $request-> name;
     $Admin->phone = $request-> phone;
     $Admin->password = $request-> password;
     $Admin->save();
 
     if($Admin){
         return response()->json("update Success!");
     }else{
         return response()->json("update fail!");
     }
     
    }
}
