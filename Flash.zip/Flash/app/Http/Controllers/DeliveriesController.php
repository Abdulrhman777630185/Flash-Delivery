<?php

namespace App\Http\Controllers;
use App\Models\Deliveries;
use App\Models\Order;

use Illuminate\Http\Request;

class DeliveriesController extends Controller
{
    
    //it's function get all Customers
   public function getAllDeliveries()
   {
    $Deliveries=Deliveries::all();
    return response()->json($Deliveries);
   }
   
   public function store(Request $request)
   {
    $Deliveries = new Deliveries;
    $Deliveries->order_id = $request-> order_id;
    $Deliveries->driver_id = $request-> driver_id;
    $Deliveries->customer_phone = $request-> customer_phone;
    $Deliveries->evaluation = null;
    $Deliveries->deliverie_status = "OrderOnWay";

    $Order =   Order::find($request-> order_id);
    $Order->order_status = "OrderOnWay";
    $Order->save();

    $Deliveries->save();

    if($Deliveries){
        return response()->json("Insert Success!");
    }else{
        return response()->json("Insert fail!");
    }
   }

   public function updateDeliveriesStatus(Request $request,$id)
   {
    $Order = Order::find($id);
    $Deliveries = Deliveries::find($id);
    
    $Order =  Order::where('id',$id)->first();
    $Order->order_status = $request->deliverie_status;
    $Order->save();

    $Temp_Id_Delivery = $request->id_delivery;
    
    $Deliveries =  Deliveries::where('id',$Temp_Id_Delivery)->first();
    $Deliveries->deliverie_status = $request->deliverie_status;
    $Deliveries->save();
    
    if($Deliveries){
        return response()->json($Deliveries);
        //return response()->json("updateDeliverieStatus Success!");
    }else{
        return response()->json("updateDeliverieStatus fail!");
    }

   }

   public function delete($Id)
    {
     $Deliveries=Deliveries::find($Id);
     $Deliveries->delete();
     if($Deliveries){
        return response()->json("delete success!");
     }else{
         return response()->json("delete fail!");
     }
    }
}
