<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Order;
use App\Models\Driver;
use App\Models\Deliveries;


class OrderController extends Controller
{
     //it's function get all Orders
   public function getAllOrders()
   {
    $Orders=Order::all();
    return response()->json($Orders);
   }
   
   

   public function delete($Id)
    {
     $Orders=Order::find($Id);
     $Orders->delete();
     if($Orders){
        return response()->json("delete Success!");
     }else{
         return response()->json("delete fail!");
     }
    }

    public function oneCustomerOrders($phone)
    {
     $CustomerOrders =  Order::where('Customer_Phone',$phone)->get();
     if($CustomerOrders){
         return response()->json($CustomerOrders);
     }else{
         return response()->json("There are no orders identical to the mobile number!");
     }
    }


    public function getDetailsOrder($id)
    {
     $Order =  Order::where('id',$id)->get();

     if($Order){
         return response()->json($Order);
     }else{
         return response()->json("There are no orders identical to the mobile number!");
     }
    }

        public function getDetailsDriver($id)
    {
       
    //$Deliveries = Deliveries::find($id);
    $Deliveries =  Deliveries::where('order_id',$id)->first();
    $driver_id = $Deliveries->driver_id;

    $Driver =  Driver::where('id',$driver_id)->first();
     if($Driver){
         return response()->json($Driver);
     }else{
         return response()->json("There are no orders identical to the mobile number!");
     }
    }



    public function store(Request $request)
   {
    $order = new Order;
    $order->customer_phone = $request-> customer_phone;
    $order->from_location = $request-> from_location;
    $order->to_location = $request-> to_location;
    $order->delivery_time = $request-> delivery_time;
    $order->order_type = $request-> order_type;
    $order->means_of_transport = $request-> means_of_transport;
    $order->payment_method = $request-> payment_method;
    $order->recipient_name = $request-> recipient_name;
    $order->recipient_phone = $request-> recipient_phone;
    $order->delivery_amount = $request-> delivery_amount;
    $order->order_status = $request-> order_status;
    $order->save();


    if($order){
        return response()->json("Insert Success!");
    }else{
        return response()->json("Insert fail!");
    }
   }
  
   public function updateOrderStatus(Request $request,$id)
   {
    $order =  Order::find($id);
    $order->order_status = $request-> order_status;
    $order->save();

    if($order){
        return response()->json("updateOrderStatus Success!");
    }else{
        return response()->json("updateOrderStatus fail!");
    }
   }



   public function getOrderStatus($Id)
   {
    $Order =  Order::where('id',$Id)->get();
    if($Order){
        return response()->json($Order);
    }else{
        return response()->json("There are no orders identical to the mobile number!");
    }
   }


}
