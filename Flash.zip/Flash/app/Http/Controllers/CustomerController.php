<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Customer;

class CustomerController extends Controller
{
    
    //it's function get all Customers
   public function getAllCustomers()
   {
    $customers=Customer::all();
    return response()->json($customers);
   }
    //it's function create customer only
   public function register(Request $request)
   {
    $customer = new Customer;
    $customer->name = $request-> name;
    $customer->phone = $request-> phone;
    $customer->password = $request-> password;
    //$customer->image = $request-> image;
    $customer->save();
    if($customer){
        return response()->json("register Success!");
    }else{
        return response()->json("register fail!");
    }
   }

   public function update(Request $request,$id)
   {
    $customer =  Customer::find($id);
    $customer->name = $request-> name;
    $customer->phone = $request-> phone;
    $customer->password = $request-> password;
    $customer->image = $request-> image;
    $customer->blocked = $request-> blocked;
    $customer->save();

    if($customer){
        return response()->json("update Success!");
    }else{
        return response()->json("update fail!");
    }
   }

   //it's function check name and password from table customers
   public function login(Request $request)
   {
    $customer = new Customer;
    $customer->name = $request-> name;
    $customer->password = $request-> password;
    $temp_name = Customer::whereIn('Name',[$customer->name])->get('Name');
    $temp_password = Customer::whereIn('Password',[$customer->password])->get('Password');
    if($temp_name->contains("Name",$customer->name) && $temp_password->contains("Password",$customer->password)){
        return response()->json("Login Success!");
    }else{
        return response()->json("Login fail!");
    }
    return response()->json("Error in laravel");
   }

   public function delete($id)
   {
    $customer=Customer::find($id);
    $customer->delete();
    if($customer){
        return response()->json("delete Success!!!");
    }else{
        return response()->json("delete fail!");
    }
   }

   public function updateCustomerName(Request $request,$id)
   {
    $customer =  Customer::find($id);
    $customer->name = $request-> name;
    $customer->save();

    if($customer){
        return response()->json("Name Success!");
    }else{
        return response()->json("Name fail!");
    }
   }


   public function updateImage(Request $request,$id)
   {
    $customer =  Customer::find($id);
    $customer->image = $request-> image;
    $customer->save();

    if($customer){
        return response()->json("updateImage Success!");
    }else{
        return response()->json("updateImage fail!");
    }
   }

   public function updateCustomerBlocked(Request $request,$id)
   {
    $customer =  Customer::find($id);
    $customer->blocked = $request-> blocked;
    $customer->save();

    if($customer){
        return response()->json("updateCustomerBlocked Success!");
    }else{
        return response()->json("updateCustomerBlocked fail!");
    }
   }

   public function getDetailsCustomer($phone)
   {
   $Customer =  Customer::where('phone',$phone)->first();
    if($Customer){
        return response()->json($Customer);
    }else{
        return response()->json("There are no orders identical to the mobile number!");
    }
   }


}
