<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\DriverController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\UrgentOrderController;
use App\Http\Controllers\DeliveriesController;
use App\Http\Controllers\PlaceController;

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
//The following links are for a table Customers. 
//---------------------------------------------------------------------------------
Route::get('getAllCustomer',[CustomerController::class,'getAllCustomers']);
Route::post('registerCustomer',[CustomerController::class,'register']);
Route::post('loginCustomer',[CustomerController::class,'login']);
Route::delete('deleteCustomer/{Id}',[CustomerController::class,'delete']);
Route::put('updateCustomer/{Id}',[CustomerController::class,'update']);
Route::put('updateCustomerName/{name}',[CustomerController::class,'updateCustomerName']);
Route::put('updateImage/{Id}',[CustomerController::class,'updateImage']);
Route::put('updateCustomerBlocked/{Id}',[CustomerController::class,'updateCustomerBlocked']);
Route::get('getDetailsCustomer/{phone}',[CustomerController::class,'getDetailsCustomer']);



//The following links are for a table Drivers. 
//-----------------------------------------------------------------------------------
Route::get('getAllDrivers',[DriverController::class,'getAllDrivers']);
Route::post('registerDriver',[DriverController::class,'register']);
Route::post('loginDriver',[DriverController::class,'login']);
Route::delete('deleteDriver/{Id}',[DriverController::class,'delete']);
Route::put('updateDriver/{Id}',[DriverController::class,'update']);
Route::put('updateDriverBlocked/{Id}',[DriverController::class,'updateDriverBlocked']);
Route::get('getDetailsDriverByID/{Id}',[DriverController::class,'getDetailsDriverByID']);
Route::post('setLocation/{Id}',[DriverController::class,'setLocation']);
Route::post('getDetailsDriverByName',[DriverController::class,'getDetailsDriverByName']);
Route::post('loginFirstDegreeDriver',[DriverController::class,'loginFirstDegreeDriver']);


//The following links are for a table Admins. 
//-----------------------------------------------------------------------------------
Route::get('getAllAdmin',[AdminController::class,'getAllAdmin']);
Route::delete('deleteAdmin/{Id}',[AdminController::class,'delete']);
Route::post('registerAdmin',[AdminController::class,'register']);
Route::post('loginAdmin',[AdminController::class,'login']);
Route::put('updateAdmin/{Id}',[AdminController::class,'update']);

//The following links are for a table Orders. 
//---------------------------------------------------------------------------------
Route::get('getAllOrders',[OrderController::class,'getAllOrders']);
Route::get('getDetailsOrder/{Id}',[OrderController::class,'getDetailsOrder']);
Route::delete('deleteOrder/{Id}',[OrderController::class,'delete']);
Route::get('oneCustomerOrders/{Phone}',[OrderController::class,'oneCustomerOrders']);
Route::get('getOrderStatus/{Id}',[OrderController::class,'getOrderStatus']);
Route::post('storeOrder',[OrderController::class,'store']);
Route::put('updateOrderStatus/{Id}',[OrderController::class,'updateOrderStatus']);
Route::get('getDetailsDriver/{Id}',[OrderController::class,'getDetailsDriver']);

//The following links are for a table UrgentOrder. 
//---------------------------------------------------------------------------------
Route::get('getAllUrgentOrders',[UrgentOrderController::class,'getAllUrgentOrders']);
Route::delete('deleteUrgentOrder/{Id}',[UrgentOrderController::class,'delete']);
Route::get('oneUrgentOrder/{Id}',[UrgentOrderController::class,'oneUrgentOrder']);
Route::post('storeUrgentOrder',[UrgentOrderController::class,'store']);
Route::put('updateUrgentOrderStatus/{Id}',[UrgentOrderController::class,'updateUrgentOrderStatus']);
Route::put('updateUrgentOrderStatusAndRescuer/{Id}',[UrgentOrderController::class,'updateUrgentOrderStatusAndRescuer']);

//The following links are for a table Deliveries. 
//---------------------------
Route::get('getAllDeliveries',[DeliveriesController::class,'getAllDeliveries']);
Route::post('storeDeliveries',[DeliveriesController::class,'store']);
Route::delete('deleteDeliveries/{Id}',[DeliveriesController::class,'delete']);
Route::put('updateDeliveriesStatus/{Id}',[DeliveriesController::class,'updateDeliveriesStatus']);




//The following links are for a table Orders. 
//---------------------------------------------------------------------------------
Route::get('getAllPlaces',[PlaceController::class,'getAllPlaces']);
Route::post('storePlace',[PlaceController::class,'storePlace']);
Route::get('getLatLng/{description}',[PlaceController::class,'getLatLng']);











